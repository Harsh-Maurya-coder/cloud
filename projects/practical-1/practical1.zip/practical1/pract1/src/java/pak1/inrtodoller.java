package pak1;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "inrtodoller")
public class inrtodoller {

    // INR to Dollar
    @WebMethod(operationName = "inrToDollar")
    public String inrToDollar(@WebParam(name = "a") double a) {

        double dollar = a / 83.17;
        return a + " INR = " + dollar + " Dollar";
    }

    // Dollar to INR
    @WebMethod(operationName = "dollarToInr")
    public String dollarToInr(@WebParam(name = "a") double a) {

        double inr = a * 83.17;
        return a + " Dollar = " + inr + " INR";
    }

    // Addition of Two Numbers
    @WebMethod(operationName = "addNumbers")
    public int addNumbers(@WebParam(name = "a") int a,
                          @WebParam(name = "b") int b) {

        return a + b;
    }

    // Square of Number
    @WebMethod(operationName = "square")
    public int square(@WebParam(name = "n") int n) {

        return n * n;
    }

    // Even or Odd
    @WebMethod(operationName = "evenOdd")
    public String evenOdd(@WebParam(name = "n") int n) {

        if (n % 2 == 0)
            return "Even";
        else
            return "Odd";
    }

    // Factorial
    @WebMethod(operationName = "factorial")
    public int factorial(@WebParam(name = "n") int n) {

        int fact = 1;

        for(int i = 1; i <= n; i++){
            fact = fact * i;
        }

        return fact;
    }
}