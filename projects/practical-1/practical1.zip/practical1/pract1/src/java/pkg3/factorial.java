/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg3;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author harsh
 */
@WebService(serviceName = "factorial")
public class factorial {

    // Factorial
    @WebMethod(operationName = "factorial")
    public int factorial(@WebParam(name = "n") int n) {

        int fact = 1;
        for(int i = 1; i <= n; i++){
            fact = fact * i;
        }
        return fact;
    }
}
