<%-- 
    Document   : output
    Created on : 10 Mar, 2026, 5:34:55 PM
    Author     : harsh
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        
                    <%-- start web service invocation --%><hr/>
    <%
    try {
	pak1.Inrtodoller_Service service = new pak1.Inrtodoller_Service();
	pak1.Inrtodoller port = service.getInrtodollerPort();
	 // TODO initialize WS operation arguments here
	double a = Double.parseDouble(request.getParameter("t1"));
	// TODO process result here
	java.lang.String result = port.operation(a);
	out.println("Result = "+result);
    } catch (Exception ex) {
	// TODO handle custom exceptions here
    }
    %>
    <%-- end web service invocation --%><hr/>
    </body>
</html>
