<%-- 
    Document   : inputf
    Created on : 10 Mar, 2026, 7:24:27 PM
    Author     : harsh
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
         <form action ="outputf.jsp">
            factorial
            <input type="text" name="t1">
            <input type="submit" name="find">
        </form>
    </body>
</html>
