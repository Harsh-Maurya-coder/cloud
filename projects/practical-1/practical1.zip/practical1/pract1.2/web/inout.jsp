<%-- 
    Document   : inout
    Created on : 10 Mar, 2026, 5:34:41 PM
    Author     : harsh
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <form action ="output.jsp">
            inrtodoller
            <input type="text" name="t1">
            <input type="submit" name="convertor">
        </form>
    </body>
</html>
