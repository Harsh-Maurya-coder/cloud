<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Factorial Result</title>
</head>

<body>

<hr/>

<%

try {

    // input.jsp se number lena
    int n = Integer.parseInt(request.getParameter("t1"));

    // web service call
    pkg2.Factorial_Service service = new pkg2.Factorial_Service();
    pkg2.Factorial port = service.getFactorialPort();

    int result = port.factorial(n);

    out.println("Factorial of " + n + " = " + result);

} catch (Exception ex) {

    out.println("Error: " + ex);

}

%>

<hr/>

</body>
</html>