package package1;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.DELETE;

@Path("generic")
public class StringOperations {

    @Context
    private UriInfo context;

    public StringOperations() {
    }

    @GET
    @Produces("application/xml")
    public String getXml() {
        throw new UnsupportedOperationException();
    }

    @PUT
    @Consumes("application/xml")
    public void putXml(String content) {
    }

    // Uppercase
    @PUT
    @Consumes(MediaType.TEXT_HTML)
    @Path("/Uppercase")
    public String toUppercaseMethod(String str) {
        return str.toUpperCase();
    }

    // Lowercase
    @PUT
    @Consumes(MediaType.TEXT_HTML)
    @Path("/Lowercase")
    public String toLowercaseMethod(String str) {
        return str.toLowerCase();
    }

    // Add Two Numbers
    @GET
    @Path("/add/{a}/{b}")
    @Produces(MediaType.TEXT_PLAIN)
    public String addNumbers(@PathParam("a") int a,
                             @PathParam("b") int b) {
        int sum = a + b;
        return "Sum = " + sum;
    }

    // Subtract Numbers
    @GET
    @Path("/subtract/{a}/{b}")
    @Produces(MediaType.TEXT_PLAIN)
    public String subtractNumbers(@PathParam("a") int a,
                                  @PathParam("b") int b) {
        int result = a - b;
        return "Result = " + result;
    }

    // Multiply Numbers
    @GET
    @Path("/multiply/{a}/{b}")
    @Produces(MediaType.TEXT_PLAIN)
    public String multiplyNumbers(@PathParam("a") int a,
                                  @PathParam("b") int b) {
        int result = a * b;
        return "Result = " + result;
    }

    // Divide Numbers
    @GET
    @Path("/divide/{a}/{b}")
    @Produces(MediaType.TEXT_PLAIN)
    public String divideNumbers(@PathParam("a") int a,
                                @PathParam("b") int b) {
        int result = a / b;
        return "Result = " + result;
    }

    // Reverse String
    @GET
    @Path("/reverse/{text}")
    @Produces(MediaType.TEXT_PLAIN)
    public String reverseString(@PathParam("text") String text) {
        StringBuilder sb = new StringBuilder(text);
        return sb.reverse().toString();
    }

    // Length of String
    @GET
    @Path("/length/{text}")
    @Produces(MediaType.TEXT_PLAIN)
    public String stringLength(@PathParam("text") String text) {
        return "Length = " + text.length();
    }
    
    @DELETE
    @Path("/delete/{id}")
    @Produces(MediaType.TEXT_PLAIN)
    public String deleteData(@PathParam("id") int id)
    {
        return "Record with id " + id + " deleted";
    }
}