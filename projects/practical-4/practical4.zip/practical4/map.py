import webbrowser

location = input("Enter location: ")

url = f"https://www.google.com/maps/search/?api=1&query={location}"

webbrowser.open(url)