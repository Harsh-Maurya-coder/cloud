package pkg2;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

@WebService(serviceName = "factorial")
public class factorial {

    // Factorial
    @WebMethod(operationName = "factorial")
    public int factorial(@WebParam(name = "n") int n) {

        int fact = 1;
        for(int i = 1; i <= n; i++){
            fact = fact * i;
        }
        return fact;
    }

    // Fibonacci Series
    @WebMethod(operationName = "fibonacci")
    public String fibonacci(@WebParam(name = "n") int n) {

        int a = 0, b = 1, c;
        String result = a + " " + b;

        for(int i = 2; i < n; i++){
            c = a + b;
            result = result + " " + c;
            a = b;
            b = c;
        }

        return result;
    }

    // Addition
    @WebMethod(operationName = "add")
    public int add(@WebParam(name = "a") int a,
                   @WebParam(name = "b") int b) {

        return a + b;
    }

    // Sum from 0 to n
    @WebMethod(operationName = "sumToN")
    public int sumToN(@WebParam(name = "n") int n) {

        int sum = 0;

        for(int i = 0; i <= n; i++){
            sum = sum + i;
        }

        return sum;
    }

    // Square
    @WebMethod(operationName = "square")
    public int square(@WebParam(name = "n") int n) {

        return n * n;
    }

    // Even or Odd
    @WebMethod(operationName = "evenOdd")
    public String evenOdd(@WebParam(name = "n") int n) {

        if(n % 2 == 0)
            return "Even";
        else
            return "Odd";
    }
}