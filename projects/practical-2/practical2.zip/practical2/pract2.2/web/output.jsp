<%-- 
    Document   : output
    Created on : 10 Mar, 2026, 5:45:41 PM
    Author     : harsh
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
           <%-- start web service invocation --%><hr/>
    <%
    try {
	pkg1.Operation_Service service = new pkg1.Operation_Service();
	pkg1.Operation port = service.getOperationPort();
	 // TODO initialize WS operation arguments here
        int a = Integer.parseInt(request.getParameter("t1"));
        int b = Integer.parseInt(request.getParameter("t2"));
	// TODO process result here
	int result = port.addition(a, b);
	out.println("Result = "+result);
    } catch (Exception ex) {
	// TODO handle custom exceptions here
    }
    %>
    <%-- end web service invocation --%><hr/>

    </body>
</html>
