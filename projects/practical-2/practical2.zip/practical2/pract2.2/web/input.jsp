<%-- 
    Document   : input
    Created on : 10 Mar, 2026, 5:45:33 PM
    Author     : harsh
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <form action="output.jsp">

        Enter First Number:
        <input type="text" name="t1">
        <br><br>

        Enter Second Number:
        <input type="text" name="t2">
        <br><br>

        <input type="submit" value="Add">

    </form>
    </body>
</html>
